# xv6-Lottery-Scheduling By Trivendra Raut 111503060 OS Project
A lottery scheduling code for xv6 system

Steps done in order to replace round robin scheduling with lottery scheduling.
1. Download the xv6-3.tar file with default round robin scheduling.
What is XV6?
From the xv6 readme:
   xv6 is a re-implementation of Dennis Ritchie's and Ken Thompson's Unix
   Version 6 (v6).  xv6 loosely follows the structure and style of v6,
   but is implemented for a modern x86-based multiprocessor using ANSI C.

For more information on xv6, see the website:
   http://pdos.csail.mit.edu/6.828/xv6/

To obtain the xv6 source code, copy the tarball and then extract it:
   cp ~cs537-2/ta/xv6/xv6.tar.gz


2. Unzip the .tar file.

3. Add a lottery scheduler to xv6
----------------------
 Replace the current round robin scheduler in xv6 with a lottery scheduler. The basic idea is simple: assign each running process a slice of the processor in proportion to the number of tickets it has. The more tickets a process has, the more it runs. Each time slice, a randomized lottery determines the winner of the lottery; that winning process is the one that runs for that time slice.

 Setting Tickets
----------------------
Implement a new system call to set the number of tickets. The prototype of the system call is:

int settickets(int)

Implementing Scheduler
----------------------
Implement a second system call to gather some statistics about all the running process. The prototype for the second system call is

int getpinfo(struct pstat *)

 This routine returns some information about all running processes, including how many times each has been chosen to run and the process ID of each. 

The main modified files are as follow:
include/
+pstat.h
+random.h
++syscall.h

user/
++user.h
++usys.S

kernel/
++sysfunc.h
++syscall.c
++sysproc.c
++proc.h
++proc.c


3. Testing: In "xv6-lottery" folder,Use the following commands to compile the xv6 system and run it.

```
$ make
$ make qemu
```

4. In qemu emulator's xv6 system:

    4.1.  Use the following code to set tickets to a program.
    ```
    tickets <num_of_tickets> <program_name>
    ```
      For example,
      ```
      tickets 3 spin 
      tickets 2 spin1
      tickets 1 spin2
      ```
      , where spin, spin1, spin2 are simply a programs that run an infinite loop.

      4.2. use the following command to get this information for every 100 xv6 ticks.
      ```
      ps -r
      ```
5. Based on ticks value every 100 xv6 ticks for 3 processes (Let spin be process A, spin1 process B, spin2 process C);
Excel sheet is formed in 'graph' folder - "Ticks value for 3 processes.xlsx" and graph is drawn using insert chart option in Excel.And 
graph is exported as image from excel and saved as "graph.png".


// Mutual exclusion spin locks.

#include "types.h"
#include "stat.h"
#include "user.h"


int
main(void)
{
  int a = 0;
  while(1){
	a++;		
  }
}

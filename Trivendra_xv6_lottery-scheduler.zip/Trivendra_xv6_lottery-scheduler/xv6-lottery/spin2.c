// Mutual exclusion spin locks.

#include "types.h"
#include "stat.h"
#include "user.h"


int
main(void)
{
  int b = 0;
  while(1){
	b+ = 2;		
  }
}
